<?php
error_reporting( E_ALL & ~E_DEPRECATED & ~E_NOTICE );
if(!mysql_connect("localhost","root","1234"))
{
	die('oops connection problem ! --> '.mysql_error());
}
if(!mysql_select_db("lng_prop"))
{
	die('oops database selection problem ! --> '.mysql_error());
}

?>