CREATE SCHEMA `lng_prop` ;

/*Staff Table*/
CREATE TABLE `lng_prop`.`staff` (
  `staffNo` INT NOT NULL AUTO_INCREMENT,
  `fName` VARCHAR(45) NOT NULL,
  `lName` VARCHAR(45) NOT NULL,
  `position` VARCHAR(45) NULL,
  `sex` VARCHAR(1) NULL,
  `dob` DATE NULL,
  `salary` DECIMAL(5,2) NULL,
  PRIMARY KEY (`staffNo`))
COMMENT = 'Contains information on all staff memebers that will be responsible for the facilititing the selling and renting of the listings';
ALTER TABLE `lng_prop`.`staff` 
CHANGE COLUMN `salary` `salary` DECIMAL(7,2) NULL DEFAULT NULL ;

ALTER TABLE `lng_prop`.`staff` 
DROP COLUMN `salary`,
ADD COLUMN `cellNum` VARCHAR(10) NULL AFTER `dob`,
ADD COLUMN `email` VARCHAR(45) NULL AFTER `cellNum`;

/*Owner Table*/
CREATE TABLE `lng_prop`.`owner` (
  `ownerID` INT NOT NULL AUTO_INCREMENT,
  `fName` VARCHAR(45) NOT NULL,
  `lName` VARCHAR(45) NOT NULL,
  `sex` VARCHAR(1) NOT NULL,
  `dob` DATE NOT NULL,
  `address` VARCHAR(65) NOT NULL,
  `telNo` VARCHAR(10) NULL,
  `cellNo` VARCHAR(10) NULL,
  PRIMARY KEY (`ownerID`))
COMMENT = 'Contains information of all owners of each property for sale/rent';

ALTER TABLE `lng_prop`.`owner` 
ADD COLUMN `email` VARCHAR(45) NULL AFTER `cellNo`;


/*Property Table*/
CREATE TABLE `lng_prop`.`property` (
  `propID` INT NOT NULL AUTO_INCREMENT,
  `street` VARCHAR(35) NOT NULL,
  `city` VARCHAR(35) NOT NULL,
  `postalCode` VARCHAR(6) NOT NULL,
  `type` VARCHAR(10) NULL,
  `commercial/residential` VARCHAR(15) NULL,
  `rent/sale` VARCHAR(5) NULL,
  `staffNo` INT NULL,
  `ownerNo` INT NULL,
  PRIMARY KEY (`propID`),
  INDEX `staffNo_idx` (`staffNo` ASC),
  INDEX `ownerNo_idx` (`ownerNo` ASC),
  CONSTRAINT `staffNo`
    FOREIGN KEY (`staffNo`)
    REFERENCES `lng_prop`.`staff` (`staffNo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `ownerNo`
    FOREIGN KEY (`ownerNo`)
    REFERENCES `lng_prop`.`owner` (`ownerID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
COMMENT = 'This table stores all the information for the properties available for rent/sale';

ALTER TABLE `lng_prop`.`property` 
ADD COLUMN `area` VARCHAR(45) NOT NULL AFTER `street`,
ADD COLUMN `description` VARCHAR(100) NOT NULL AFTER `rent/sale`;

ALTER TABLE `lng_prop`.`property` 
ADD COLUMN `numBeds` INT NULL AFTER `description`,
ADD COLUMN `numBaths` INT NULL AFTER `numBeds`,
ADD COLUMN `numGarages` INT NULL AFTER `numBaths`;

ALTER TABLE `lng_prop`.`property` 
CHANGE COLUMN `description` `description` VARCHAR(5000) NOT NULL ;
ALTER TABLE `lng_prop`.`property` 
ADD COLUMN `summDescription` VARCHAR(1000) NULL AFTER `numGarages`;

ALTER TABLE `lng_prop`.`property` 
ADD COLUMN `price` DECIMAL(8,2) NULL AFTER `rent/sale`;

ALTER TABLE `lng_prop`.`property` 
ADD COLUMN `heading` VARCHAR(45) NULL AFTER `price`;


/*Image table*/
CREATE TABLE `lng_prop`.`image` (
  `imgID` INT NOT NULL AUTO_INCREMENT,
  `imgName` VARCHAR(20) NULL,
  `imagePath` VARCHAR(45) NOT NULL,
  `propNo` INT NOT NULL,
  PRIMARY KEY (`imgID`),
  INDEX `propNo_idx` (`propNo` ASC),
  CONSTRAINT `propNo`
    FOREIGN KEY (`propNo`)
    REFERENCES `lng_prop`.`property` (`propID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
COMMENT = 'Contains image path of images to be displyed on the website';
ALTER TABLE `lng_prop`.`image` 
CHANGE COLUMN `imagePath` `imagePath` VARCHAR(100) NOT NULL ;

ALTER TABLE `lng_prop`.`image` 
ADD COLUMN `imageGal` VARCHAR(100) NULL AFTER `propNo`;

ALTER TABLE `lng_prop`.`image` 
DROP COLUMN `imageGal`;


/*Image Gallery*/
CREATE TABLE `lng_prop`.`imagegal` (
  `imgID` INT NOT NULL AUTO_INCREMENT,
  `imgName` VARCHAR(45) NULL,
  `imagePath` VARCHAR(45) NULL,
  `prop_No` INT NULL,
  PRIMARY KEY (`imgID`),
  INDEX `propNo_idx` (`prop_No` ASC),
  CONSTRAINT `prop_No`
    FOREIGN KEY (`prop_No`)
    REFERENCES `lng_prop`.`property` (`propID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);


/*Client table*/
CREATE TABLE `lng_prop`.`client` (
  `cleintID` INT NOT NULL AUTO_INCREMENT,
  `fName` VARCHAR(45) NULL,
  `lName` VARCHAR(45) NULL,
  `message` VARCHAR(100) NULL,
  PRIMARY KEY (`cleintID`));
  
  ALTER TABLE `lng_prop`.`client` 
CHANGE COLUMN `fName` `name` VARCHAR(45) NULL DEFAULT NULL ,
CHANGE COLUMN `lName` `email` VARCHAR(45) NULL DEFAULT NULL ;

ALTER TABLE `lng_prop`.`client` 
CHANGE COLUMN `name` `name` VARCHAR(45) NOT NULL ,
CHANGE COLUMN `email` `email` VARCHAR(45) NOT NULL ,
CHANGE COLUMN `message` `message` VARCHAR(100) NOT NULL ;


/*Prop View*/
USE `lng_prop`;
CREATE 
     OR REPLACE ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `prop_view` AS
    SELECT 
        `p`.`propID` AS `propID`,
        `p`.`heading` as `heading`,
        `p`.`summDescription` AS `summDescription`,
        `p`.`price` AS `price`,
        `p`.`numBeds` AS `numBeds`,
        `p`.`numBaths` AS `numBaths`,
        `p`.`numGarages` AS `numGarages`,
        `i`.`imagePath` AS `imagePath`
    FROM
        (`property` `p`
        JOIN `image` `i`)
    WHERE
        (`p`.`propID` = `i`.`propNo`);

/*Staff View*/
USE `lng_prop`;
CREATE  OR REPLACE VIEW `staff_view` AS
	select s.staffNo, s.fName, s.lName, s.cellNum, s.email, p.propID
    from staff as s, property as p  
    where p.staffNo = s.staffNo;


