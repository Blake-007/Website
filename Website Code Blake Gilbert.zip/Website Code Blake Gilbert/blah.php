<?php

session_start();

$regValue = $_GET['regName'];

echo "Your registration is: ".$regValue.".";

?>


<!DOCTYPE html>
<html lang = eng>
	<head>
		<meta charset = "UTF-8">
		<title>blah</title>
		<link rel = "stylesheet" type = "text/css" href = "CSS/style.css">
	</head>
	
	<body>
		
<p><a href="gallery.php">Back to gallery</a>
	</body>
	
</html>